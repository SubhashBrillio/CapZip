import React from "react";
import { useNavigate } from "react-router-dom";

const LandingPage = () => {
    const navigate = useNavigate();

    return (
        <div style={styles.container}>
            <h1 style={styles.heading}>Welcome to Our Platform</h1>
            <p style={styles.description}>Secure and seamless user experience</p>
            <div style={styles.buttonContainer}>
                <button onClick={() => navigate("/login")} style={styles.button}>Login</button>
                <button onClick={() => navigate("/register")} style={styles.button}>Register</button>
            </div>
        </div>
    );
};

const styles = {
    container: {
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        height: "100vh",
        marginTop: "-100px", 
        backgroundColor: "#f5f5f5",
        textAlign: "center",
    },
    heading: {
        fontSize: "32px",
        marginBottom: "10px",
    },
    description: {
        fontSize: "18px",
        marginBottom: "20px",
    },
    buttonContainer: {
        display: "flex",
        gap: "15px",
        justifyContent: "center", // Center the buttons
    },
    button: {
        padding: "10px 20px",
        fontSize: "16px",
        border: "none",
        borderRadius: "5px",
        cursor: "pointer",
        backgroundColor: "#007bff",
        color: "white",
        flex: 1, // Allow buttons to grow equally
        minWidth: "120px", // Ensure buttons are at least this wide
        textAlign: "center",
    },
};

export default LandingPage;