import React from "react";
import { Link, useNavigate } from "react-router-dom";

const UserMenu = () => {
    const navigate = useNavigate();

    const handleLogout = () => {
        localStorage.removeItem("userToken");
        localStorage.removeItem("mobileNumber");
        navigate("/login");
    };

    return (
        <div style={{ textAlign: "center", marginTop: "50px" }}>
            <h2>Welcome to User Dashboard</h2>

            <nav>
                <ul style={horizontalMenuStyle}>
                    <li style={horizontalMenuItemStyle}>
                        <Link to="/userinfo" style={buttonStyle}>User Info</Link>
                    </li>
                    <li style={horizontalMenuItemStyle}>
                        <Link to="/plans" style={buttonStyle}>Plans</Link>
                    </li>
                    <li style={horizontalMenuItemStyle}>
                        <Link to="/datausage" style={buttonStyle}>Data Usage</Link>
                    </li>
                    <li style={horizontalMenuItemStyle}>
                        <Link to="/tickets" style={buttonStyle}>Support Tcikets</Link>
                    </li>
                    <li style={horizontalMenuItemStyle}>
                        <button onClick={handleLogout} style={buttonStyle}>Logout</button>
                    </li>
                </ul>
            </nav>
        </div>
    );
};

// Styling for horizontal menu layout
const horizontalMenuStyle = {
    listStyle: "none",
    padding: 0,
    display: "flex",  // Use flexbox to align items horizontally
    justifyContent: "center",  // Center the items horizontally
    gap: "20px",  // Space between the items (buttons)
};

// Styling for each menu item (li)
const horizontalMenuItemStyle = {
    display: "flex",  // Makes sure the item behaves like a flex container
    alignItems: "center",  // Vertically centers the content within each item
    justifyContent: "center",  // Centers content horizontally
};

// Styling for all buttons (links styled as buttons)
const buttonStyle = {
    padding: "10px 20px",
    backgroundColor: "blue",
    color: "white",
    border: "none",
    cursor: "pointer",
    fontSize: "16px",
    borderRadius: "5px",
    textDecoration: "none",  // Remove underline for links
    fontWeight: "bold",
    textAlign: "center",  // Center text within buttons
};

// Optional: Hover effect for buttons
buttonStyle[':hover'] = {
    backgroundColor: "darkblue",
};

export default UserMenu;
