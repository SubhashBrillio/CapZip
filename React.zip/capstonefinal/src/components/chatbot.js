import React, { useState, useEffect } from "react";
import axios from "axios";
import "./chatbot.css";
import UserMenu from "./userMenu";



const Chatbot = () => {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [faqList, setFaqList] = useState([]);
  const [showOptions, setShowOptions] = useState(false);
  const [showFaqs, setShowFaqs] = useState(false);
  const [showTicketForm, setShowTicketForm] = useState(false);
  const [ticket, setTicket] = useState({
    employId: "",
    ticketDescription: "",
  });
  const [customerId, setCustomerId] = useState(() => {
      return localStorage.getItem("UserId") || null;

  });
  const formatDate = (date) => {
    const pad = (num) => num.toString().padStart(2, '0');  // Add leading zero for single-digit months, days, etc.
    
    const year = date.getFullYear();
    const month = pad(date.getMonth() + 1);  // Month is zero-indexed, so we add 1
    const day = pad(date.getDate());
    const hours = pad(date.getHours());
    const minutes = pad(date.getMinutes());
    const seconds = pad(date.getSeconds());
  
    return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
  };

  useEffect(() => {
    const fetchFaqs = async () => {
      try {
        const res = await axios.get("http://localhost:1121/chatbot/faqs");
        setFaqList(res.data);
      } catch (error) {
        console.error("Error fetching FAQs", error);
      }
    };
    fetchFaqs();
  }, []);

  const sendMessage = async (text) => {
    let newMessages = [...messages, { text, sender: "user" }];
    setMessages(newMessages);
    
    let response = "Sorry, I don't understand that.";

    if (text.toLowerCase() === "hi") {
      response = "Hi, how may I help you?";
      setShowOptions(true);
    } else if (text === "Raise Ticket") {
      setShowTicketForm(true);
      return;
    } else if (text === "Check My Ticket Status") {
      if (!customerId) {
        response = "Customer ID not found. Please log in again.";
      } else {
        try {
            alert(customerId)
          const res = await axios.get(`http://localhost:1121/chatbot/ticketstatus/${customerId}`);
          response = res.data;
        } catch (error) {
          response = "Error fetching ticket status.";
        }
      }
    } else if (text === "FAQs") {
      setShowFaqs(true);
      setMessages([...newMessages, ...faqList.map(faq => ({ text: `${faq.question}: ${faq.answer}`, sender: "bot" }))]);
      return;
    }

    setMessages([...newMessages, { text: response, sender: "bot" }]);
  };

  const handleTicketChange = (e) => {
    const { name, value } = e.target;
    setTicket({ ...ticket, [name]: value });
  };

  const submitTicket = async () => {
    if (!ticket.employId || !ticket.ticketDescription) {
      alert("Please fill in all required fields.");
      return;
    }

    // New ticket structure
    const newTicket = {
      user_id: customerId, // Use the logged-in user id
      employ_id: ticket.employId,
      issue: ticket.ticketDescription,
      status: "Open", // Initially setting status to "Open"
      created_at: formatDate(new Date()), 
      updated_at: new Date().toISOString(), // Set the updated_at to the current time
    };

    try {
      await axios.post("http://localhost:1121/supportTickets/addSupportTickets", newTicket, {
        headers: { "Content-Type": "application/json" },
      });
      setMessages([...messages, { text: "Your ticket has been raised successfully!", sender: "bot" }]);
      setShowTicketForm(false);
      setTicket({ employId: "", ticketDescription: "" });
    } catch (error) {
      alert(`Error: ${error.response?.data?.message || "Failed to submit ticket."}`);
    }
  };

  return (
    
    <div className="chatbot-container">
      
      <div className="chatbot-header">Telexa</div>
      <div className="chatbot-messages">
        {messages.map((msg, index) => (
          <div key={index} className={msg.sender}>{msg.text}</div>
        ))}

        {showTicketForm && (
          <div className="chatbot-ticket-form">
            <h4>Raise a Ticket</h4>
            Employ Id:
            <input
              type="text"
              name="employId"
              placeholder="Employ ID"
              value={ticket.employId}
              onChange={handleTicketChange}
              required
            /> <br/>
            Issue:
            <textarea
              name="ticketDescription"
              placeholder="Describe your issue"
              value={ticket.ticketDescription}
              onChange={handleTicketChange}
              required
            />
            <button onClick={submitTicket}>Submit</button>
          </div>
        )}
      </div>

      {showOptions && !showTicketForm && (
        <div className="chatbot-options">
          <button onClick={() => sendMessage("Raise Ticket")}>Raise Ticket</button>
          <button onClick={() => sendMessage("Check My Ticket Status")}>Check My Ticket Status</button>
          <button onClick={() => sendMessage("FAQs")}>FAQs</button>
        </div>
      )}

      <div className="chatbot-input">
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Type Hi to start conversation..."
        />
        <button onClick={() => sendMessage(input)}>Send</button>
      </div>
    </div>
  );
};

export default Chatbot;
