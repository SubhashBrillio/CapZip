import React, { useState } from 'react';
import AuthService from '../services/authService';
import { useNavigate } from 'react-router-dom';

const Login = () => {
    const [data, setState] = useState({
        identifier: '', // Use a single field for both mobile number and email
        password: ''
    });

    const [errorMessage, setErrorMessage] = useState(""); // State to store login error
    const navigate = useNavigate();

    const handleChange = (event) => {
        setState({
            ...data,
            [event.target.name]: event.target.value
        });
    };

    const handleLogin = async (e) => {
        e.preventDefault();
        setErrorMessage(""); // Clear previous errors

        try {
            const response = await AuthService.login(data.identifier, data.password);
            
            if (response) {
                localStorage.setItem("userToken", response.data); // Store JWT token
                navigate("/UserMenu"); // Redirect to UserMenu.js
            }
        } catch (error) {
            console.error("Login failed", error);
            setErrorMessage("Wrong username or password"); // Display error on screen
        }
    };

    return (
        <div style={containerStyle}>
            <h2 style={headingStyle}>Login</h2>

            <form onSubmit={handleLogin} style={formStyle}>
                <div style={inputGroupStyle}>
                    <label style={labelStyle}>MOBILE NUMBER OR EMAIL</label>
                    <input
                        type="text"
                        name="identifier"
                        value={data.identifier}
                        onChange={handleChange}
                        placeholder="Enter Mobile Number or Email"
                        required
                        style={inputStyle}
                        onFocus={(e) => (e.target.placeholder = "")}
                        onBlur={(e) => (e.target.placeholder = "Enter Mobile Number or Email")}
                    />
                </div>

                <div style={inputGroupStyle}>
                    <label style={labelStyle}>PASSWORD</label>
                    <input
                        type="password"
                        name="password"
                        value={data.password}
                        onChange={handleChange}
                        placeholder="Enter Password"
                        required
                        style={inputStyle}
                        onFocus={(e) => (e.target.placeholder = "")}
                        onBlur={(e) => (e.target.placeholder = "Enter Password")}
                    />
                </div>

                <div style={buttonContainerStyle}>
                    <input type="submit" value="Login" style={buttonStyle} />
                </div>
            </form>

            {/* Display error message if login fails */}
            {errorMessage && <p style={errorMessageStyle}>{errorMessage}</p>}
        </div>
    );
};

// Styling for the login page
const containerStyle = {
    textAlign: "center",
    marginTop: "50px",
    maxWidth: "400px",
    margin: "0 auto"
};

const headingStyle = {
    color: "#333",
    fontSize: "24px",
    fontWeight: "bold",
    marginBottom: "20px"
};

const formStyle = {
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    padding: "20px",
    borderRadius: "8px",
    boxShadow: "0 4px 8px rgba(0, 0, 0, 0.1)",
    backgroundColor: "#fff"
};

const inputGroupStyle = {
    marginBottom: "20px",
    width: "100%"
};

const labelStyle = {
    fontSize: "16px",
    color: "#333",
    marginBottom: "8px",
    textAlign: "left",
    width: "100%",
    display: "block"
};

const inputStyle = {
    padding: "10px",
    width: "100%",
    maxWidth: "300px",
    fontSize: "16px",
    borderRadius: "5px",
    border: "1px solid #ccc",
    boxSizing: "border-box",
    outline: "none",
    marginBottom: "10px"
};

const buttonContainerStyle = {
    marginTop: "20px"
};

const buttonStyle = {
    padding: "12px 24px",
    fontSize: "16px",
    fontWeight: "bold",
    backgroundColor: "blue",
    color: "white",
    border: "none",
    borderRadius: "5px",
    cursor: "pointer",
    width: "100%",
    maxWidth: "300px"
};

const errorMessageStyle = {
    color: "red",
    fontSize: "14px",
    marginTop: "20px",
    fontWeight: "bold"
};

export default Login;
