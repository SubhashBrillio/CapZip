import axios from 'axios';

const API_URL = 'http://localhost:1121/accounts';

// Login function (supports both mobile number and email)
const login = (identifier, password) => {
    return axios.post(`${API_URL}/generateToken`, {
        username: identifier, // Can be either mobile number or email
        password: password
    }).then(response => {
        if (response.data) {
            localStorage.setItem("userToken", response.data);

            // Determine if the identifier is an email or mobile number
            if (identifier.includes("@")) {
                localStorage.setItem("email", identifier);
                localStorage.removeItem("mobileNumber"); // Clear mobile number if email is used
            } else {
                localStorage.setItem("mobileNumber", identifier);
                localStorage.removeItem("email"); // Clear email if mobile number is used
            }
        }
        return response.data;
    });
};

// Get stored token
const getCurrentUserToken = () => {
    return localStorage.getItem("userToken");
};

// Get stored mobile number
const getCurrentUserMobile = () => {
    return localStorage.getItem("mobileNumber");
};

// Get stored email
const getCurrentUserEmail = () => {
    return localStorage.getItem("email");
};

// Logout function to clear user data
const logout = () => {
    localStorage.removeItem("userToken");
    localStorage.removeItem("mobileNumber");
    localStorage.removeItem("email");
};

export default {
    login,
    getCurrentUserToken,
    getCurrentUserMobile,
    getCurrentUserEmail,
    logout
};