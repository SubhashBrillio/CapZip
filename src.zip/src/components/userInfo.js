import React, { useEffect, useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import AuthService from "../services/authService";
import UserMenu from "./userMenu";

const UserInfo = () => {
    const [user, setUser] = useState(null);
    const navigate = useNavigate();

    useEffect(() => {
        const token = AuthService.getCurrentUserToken();
        const mobileNumber = AuthService.getCurrentUserMobile();
        const email = AuthService.getCurrentUserEmail();

        if (!token) {
            console.error("No JWT token found. Redirecting to login.");
            navigate("/login");
            return;
        }

        console.log("Mobile Number:", mobileNumber);
        console.log("Email:", email);

        let apiUrl = mobileNumber 
            ? `http://localhost:1121/accounts/getAccountByMobileNumber/${mobileNumber}`
            : `http://localhost:1121/accounts/getAccountByEmail/${email}`;

        console.log("API URL:", apiUrl);

        axios.get(apiUrl, {
            headers: {
                Authorization: `Bearer ${token}`
            }
        })
        .then((response) => {
            setUser(response.data);
            // alert(response.data.userId);
            localStorage.setItem("UserId",response.data.userId);
           
        })
        .catch((error) => {
            console.error("Error fetching user:", error);
            if (error.response) {
                console.error(`Error Status: ${error.response.status}, Message: ${error.response.data}`);
            }
            if (error.response && error.response.status === 403) {
                navigate("/login");
            }
        });
    }, [navigate]);

    const handleLogout = () => {
        AuthService.logout();
        navigate("/login");
    };

    return (
     
        <div style={{ textAlign: "center", marginTop: "50px" }}>
            <UserMenu/>
            <h2>Welcome to User Dashboard</h2>
            {user ? (
                <div>
                    {/* <p><strong>User ID:</strong> {user.userId}</p> */}
                    <p><strong>Mobile:</strong> {user.mobileNumber}</p>
                    <p><strong>Email:</strong> {user.email}</p>
                    <p><strong>Full Name:</strong> {user.firstName +" "+ user.lastName}</p>
                    {/* <p><strong>First Name:</strong> {user.firstName}</p>
                    <p><strong>Last Name:</strong> {user.lastName}</p>
                    <p><strong>Security Question:</strong> {user.securityQuestion}</p>
                    <p><strong>Security Answer:</strong> {user.securityAnswer}</p> */}
                    <p><strong>Address:</strong> {user.address || "Not provided"}</p>
                    <p><strong>Alternate Mobile Number:</strong> {user.alternateMobileNumber || "Not provided"}</p>
                    <p><strong>Account Status:</strong> {user.accountStatus}</p>

                    <button onClick={handleLogout} style={buttonStyle}>Logout</button>
                </div>
            ) : (
                <p>Loading...</p>
            )}
        </div>
    );
};

// Logout Button Style
const buttonStyle = {
    padding: "10px 20px",
    backgroundColor: "red",
    color: "white",
    border: "none",
    cursor: "pointer",
    fontSize: "16px",
    borderRadius: "5px",
    marginTop: "20px"
};

export default UserInfo;