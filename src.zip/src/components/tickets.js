import React, { useEffect, useState } from 'react';
import axios from 'axios';
import UserMenu from './userMenu';

const Tickets = () => {
  const [data, setData] = useState([]);

  useEffect(() => {
    const fetchData = async () => {
      let c = localStorage.getItem("UserId");
      
      const response = await axios.get("http://localhost:1121/supportTickets/searchAccount/" + c);
      setData(response.data);
    };
    fetchData();
  }, []);

  if (!data || Object.keys(data).length === 0) {
    return <p><div><UserMenu /></div ><center> Data Not Found</center></p>;
  }

  return (
    <div style={styles.container}>
        <UserMenu/>
      <h2 style={styles.heading}>Support Tickets</h2>
      <table style={styles.table}>
        <thead>
          <tr>
            <th style={styles.tableHeader}>Ticket Id</th>
            <th style={styles.tableHeader}>Issue</th>
            <th style={styles.tableHeader}>Status</th>
            <th style={styles.tableHeader}>Created at</th>
            <th style={styles.tableHeader}>Updated at</th>
          </tr>
        </thead>
        <tbody>
          {
            Array.isArray(data) && data.map((item) => (
              <tr key={item.ticketId}> {/* Use the ticketId as the unique key */}
                <td style={styles.tableCell}>{item.ticketId}</td>
                <td style={styles.tableCell}>{item.issue}</td>
                <td style={styles.tableCell}>{item.status}</td>
                <td style={styles.tableCell}>{item.createdAt}</td>
                <td style={styles.tableCell}>{item.updatedAt}</td>
              </tr>
            ))
          }
        </tbody>
      </table>
    </div>
  );
};

const styles = {
  container: {
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "flex-start",
    paddingTop: "50px",
    backgroundColor: "#f5f5f5",
    minHeight: "100vh",
    textAlign: "center",
  },
  heading: {
    fontSize: "28px",
    fontWeight: "bold",
    marginBottom: "20px",
    color: "#333",
  },
  table: {
    width: "80%",
    margin: "0 auto",
    borderCollapse: "collapse",
    border: "2px solid #007bff", // Border color matching button
    boxShadow: "0 4px 8px rgba(0, 0, 0, 0.1)", // Subtle shadow to lift table
  },
  tableHeader: {
    backgroundColor: "#007bff",
    color: "white",
    padding: "10px 20px",
    fontSize: "16px",
    fontWeight: "bold",
    textAlign: "center",
  },
  tableCell: {
    padding: "10px 20px",
    textAlign: "center",
    borderBottom: "1px solid #ddd", // Light border for table rows
  },
};

export default Tickets;
