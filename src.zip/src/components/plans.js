import React, {Component,useEffect, useState} from 'react';
import axios from 'axios';
import UserMenu from './userMenu';


const Plans = () =>{
  const[data,setData] = useState([])


  useEffect( () =>{
    const fetchData = async () =>{
      const response  = await axios.get("http://localhost:1121/plans/showPlans")
      setData(response.data)
    };
    fetchData();
  },[]);

  return(
    <div>
    <UserMenu/>
    <table border="3" align="center">
      <thead>
        <tr>
          <th>Plan Id</th>
          <th>Plan Name</th>
          <th>Plan Type</th>
          <th>Details</th>
          <th>Price (INR)</th>
          <th>Validity</th>
        </tr>
      </thead>
      <tbody>
        {data.map((items) => (
          <tr key={items.planId}>
            <td>{items.planId}</td>
            <td>{items.planName}</td>
            <td>{items.planType}</td>
            <td>{items.details}</td>
            <td>{items.price}</td>
            <td>{items.validity}</td>
          </tr>
        ))}
      </tbody>
    </table>
  </div>
  )

}
export default Plans;