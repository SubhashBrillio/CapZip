import React, { useEffect, useState } from 'react';
import axios from 'axios';
import UserMenu from './userMenu';
 
const Datausage = () => {
  const [data, setData] = useState([]);
 
  useEffect(() => {
    const fetchData = async () => {
        let user = localStorage.getItem("UserId");
     
      const response = await axios.get("http://localhost:1121/datausage/searchByuserId/" + user);
      setData(response.data);
    };
    fetchData();
  }, []);
 
  if (!data || Object.keys(data).length === 0) {
    return <p><div><UserMenu /></div ><canter> Data Not Found</canter></p>;
  }
 
  return (
    <div style={styles.container}>
      <UserMenu />
      {/* <h2 style={styles.heading}>Data Usage Details</h2> */}
      <div style={styles.userInfo}>
        {/* Loop through the array of data if multiple entries exist */}
        {data.map((item, index) => (
          <div key={index} style={styles.itemContainer}>
            <p><strong>User Plan ID:</strong> <b>{item.userPlanId}</b></p>
            <p><strong>User ID:</strong> <b>{item.userId}</b></p>
            <p><strong>Data Used:</strong> <b>{item.dataUsed} GB</b></p>
            <p><strong>SMS Used:</strong> <b>{item.smsUsed}</b></p>
            <p><strong>Calls Used:</strong> <b>{item.callsUsed}</b></p>
            <p><strong>Recorded Date:</strong> <b>{item.recordedDate}</b></p>
            <p>-------------------</p>
          </div>
        ))}
      </div>
    </div>
  );
};
 
const styles = {
  container: {
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "flex-start",
    paddingTop: "50px",
    backgroundColor: "#f5f5f5",
    minHeight: "100vh",
    textAlign: "center",
  },
  heading: {
    fontSize: "28px",
    fontWeight: "bold",
    marginBottom: "20px",
    color: "#333",
  },
  userInfo: {
    backgroundColor: "#fff",
    padding: "20px",
    borderRadius: "8px",
    boxShadow: "0 4px 8px rgba(0, 0, 0, 0.1)",
    marginTop: "20px",
    width: "80%",
    maxWidth: "800px",
    textAlign: "left",
    lineHeight: "1.6",
  },
};
 
export default Datausage;