import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import axios from 'axios';

const Register = () => {
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    mobileNumber: '',
    email: '',
    passwordHash: '',
    confirmPassword: '',
    securityQuestion: '',
    securityAnswer: '',
    address: '',
    alternateMobileNumber: '',
    accountStatus: 'Active'
  });

  const [errors, setErrors] = useState({});
  const [errorMessage, setErrorMessage] = useState('');
  const [successMessage, setSuccessMessage] = useState('');
  const [passwordError, setPasswordError] = useState('');
  const [confirmPasswordError, setConfirmPasswordError] = useState('');

  const navigate = useNavigate();

  const handleChange = (e) => {
    const { name, value } = e.target;

    if (name === "firstName" || name === "lastName") {
      const regex = /^[A-Za-z]*$/;
      if (value === "" || regex.test(value)) {
        setFormData({ ...formData, [name]: value });
      }
    } else if (name === "mobileNumber") {
      const sanitizedValue = value.replace(/\D/g, '');
      setFormData({ ...formData, [name]: sanitizedValue });
    } else {
      setFormData({ ...formData, [name]: value });
    }

    setErrors((prevErrors) => ({ ...prevErrors, [name]: "" }));

    // Reset password and confirm password errors when user types
    if (name === 'passwordHash') {
      setPasswordError('');
    }

    if (name === 'confirmPassword') {
      setConfirmPasswordError('');
    }
  };

  const handlePasswordChange = (e) => {
    const password = e.target.value;
    const minLength = 8;
    const containsUpperCase = /[A-Z]/.test(password);
    const containsLowerCase = /[a-z]/.test(password);
    const containsNumber = /\d/.test(password);
    const containsSpecial = /[@#$%]/.test(password);

    setFormData({ ...formData, passwordHash: password });
    setPasswordError('');

    if (password.length >= minLength &&
        containsUpperCase &&
        containsLowerCase &&
        containsNumber &&
        containsSpecial) {
      setPasswordError('');
    } else {
      setPasswordError('Weak password. Must be at least 8 characters long, with uppercase, lowercase, a number, and a special character (@, #, $, %).');
    }
  };

  const validateForm = () => {
    let newErrors = {};

    if (!formData.firstName.trim()) newErrors.firstName = 'First Name is required';
    if (!formData.lastName.trim()) newErrors.lastName = 'Last Name is required';
    if (!formData.email.trim() || !formData.email.includes('@') || !formData.email.includes('.')) {
      newErrors.email = 'Valid Email is required';
    }
    const mobileNumberPattern = /^[6-9]\d{9}$/;

    if (!formData.mobileNumber.trim()) {
      newErrors.mobileNumber = 'Mobile Number is required';
    } else if (!mobileNumberPattern.test(formData.mobileNumber)) {
      newErrors.mobileNumber = 'Please enter a valid Mobile Number (starting with 6-9 and 10 digits)';
    } else if (formData.mobileNumber.startsWith('0')) {
      newErrors.mobileNumber = 'Mobile Number cannot start with 0';
    }

    if (passwordError) {
      newErrors.passwordHash = passwordError;
    } else if (!formData.passwordHash.trim()) {
      newErrors.passwordHash = 'Password is required';
    }
    
    if (formData.passwordHash !== formData.confirmPassword) {
      newErrors.confirmPassword = 'Passwords do not match';
    }

    if (!formData.securityQuestion.trim()) newErrors.securityQuestion = 'Security question is required';
    if (!formData.securityAnswer.trim()) newErrors.securityAnswer = 'Security answer is required';

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const signup = async () => {
    try {
      const response = await axios.post('http://localhost:1121/accounts/addAccount', formData, {
        headers: {
          'Content-Type': 'application/json'
        }
      });

      setSuccessMessage('Signup Successful! Please log in.');
      setErrorMessage('');
      navigate("/userLogin");
    } catch (err) {
      setErrorMessage(err.response?.data || 'An error occurred. Please try again.');
      setSuccessMessage('');
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (validateForm()) {
      signup();
    }
  };

  return (
    <div className="signup-container" style={containerStyle}>
      <h2>Sign Up</h2>
      <form onSubmit={handleSubmit} className="signup-form" style={formStyle}>
        <table align='center' border='4'>
          <tbody>
            <tr>
              <td><label>First Name</label></td>
              <td><input type="text" name="firstName" value={formData.firstName} onChange={handleChange} style={inputStyle} /></td>
            </tr>
            {errors.firstName && <tr><td colSpan="2"><p className="error"><span style={errorStyle}>{errors.firstName}</span></p></td></tr>}

            <tr>
              <td><label>Last Name</label></td>
              <td><input type="text" name="lastName" value={formData.lastName} onChange={handleChange} style={inputStyle} /></td>
            </tr>
            {errors.lastName && <tr><td colSpan="2"><p className="error"><span style={errorStyle}>{errors.lastName}</span></p></td></tr>}

            <tr>
              <td><label>Mobile Number</label></td>
              <td><input type="text" name="mobileNumber" value={formData.mobileNumber} onChange={handleChange} style={inputStyle} /></td>
            </tr>
            {errors.mobileNumber && <tr><td colSpan="2"><p className="error"><span style={errorStyle}>{errors.mobileNumber}</span></p></td></tr>}

            <tr>
              <td><label>Email</label></td>
              <td><input type="text" name="email" value={formData.email} onChange={handleChange} style={inputStyle} /></td>
            </tr>
            {errors.email && <tr><td colSpan="2"><p className="error"><span style={errorStyle}>{errors.email}</span></p></td></tr>}

            <tr>
              <td><label>Password</label></td>
              <td><input type="password" name="passwordHash" value={formData.passwordHash} onChange={handlePasswordChange} style={inputStyle} /></td>
            </tr>
            {errors.passwordHash && <tr><td colSpan="2"><p className="error"><span style={errorStyle}>{errors.passwordHash}</span></p></td></tr>}
            
            <tr>
              <td><label>Confirm Password</label></td>
              <td><input type="password" name="confirmPassword" value={formData.confirmPassword} onChange={handleChange} style={inputStyle}/></td>
            </tr>
            {errors.confirmPassword && <tr><td colSpan="2"><p className="error"><span style={errorStyle}>{errors.confirmPassword}</span></p></td></tr>}

            <tr>
              <td><label>Security Question</label></td>
              <td>
                <select name="securityQuestion" value={formData.securityQuestion} onChange={handleChange} style={inputStyle}>
                  <option value="">Select a Security Question</option>
                  <option value="What is the name of your first pet?">What is the name of your first pet?</option>
                  <option value="What is your mother's maiden name?">What is your mother's maiden name?</option>
                  <option value="What is your favorite food?">What is your favorite food?</option>
                </select>
              </td>
            </tr>
            {errors.securityQuestion && <tr><td colSpan="2"><p className="error"><span style={errorStyle}>{errors.securityQuestion}</span></p></td></tr>}

            <tr>
              <td><label>Security Answer</label></td>
              <td><input type="text" name="securityAnswer" value={formData.securityAnswer} onChange={handleChange} style={inputStyle} /></td>
            </tr>
            {errors.securityAnswer &&  <tr><td colSpan="2"><p className="error"><span style={errorStyle}>{errors.securityAnswer}</span></p></td></tr>}
            
            {/* <tr>
              <td><label>Address</label></td>
              <td><input type="text" name="address" value={formData.address} onChange={handleChange} style={inputStyle} /></td>
            </tr>
            {errors.address && <tr><td colSpan="2"><p className="error">{errors.address}</p></td></tr>} */}

            <tr>
              <td colSpan="2"><button type="submit" style={buttonStyle}>Sign Up</button></td>
            </tr>
          </tbody>
        </table>
      </form>
     
      <p>Already have an account? <Link to="/userLogin" style={linkStyle}>Login here</Link></p>
      {successMessage && <p style={{ color: 'green' }}>{successMessage}</p>}
      {errorMessage && <p style={{ color: 'red' }}>{errorMessage}</p>}
    </div>
  );
};

// Inline styles
const containerStyle = {
  textAlign: "center",
  marginTop: "50px"
};

const formStyle = {
  marginTop: "20px"
};

const inputStyle = {
  padding: "8px",
  margin: "5px",
  width: "250px",
  borderRadius: "5px",
  border: "1px solid #ccc"
};

const buttonStyle = {
  padding: "10px 20px",
  backgroundColor: "blue",
  color: "white",
  border: "none",
  cursor: "pointer",
  fontSize: "16px",
  borderRadius: "5px",
  width: "200px"
};

const linkStyle = {
  textDecoration: "none",
  color: "blue",
  fontSize: "18px",
  fontWeight: "bold"
};

const errorStyle = {
  color: "red",
  fontSize: "18px",
  fontWeight: "5px"
}


export default Register;
