import React from 'react';
import { BrowserRouter as Router, Route, Routes, Navigate } from 'react-router-dom';
import Login from './components/login';
import UserMenu from './components/userMenu';
import UserInfo from './components/userInfo';
import ProtectedRoute from './components/protectedRoute'; // Import the ProtectedRoute component
import Register from './components/register';
import LandingPage from './components/landingpage';
import Tickets from './components/tickets';
import Chatbot from './components/chatbot';
import Plans from './components/plans';
import Datausage from './components/datausage';

function App() {
  return (
    <Router>
      <Routes>
         <Route path="/" element={<LandingPage/>}/>
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register/>}/>
        {/* Protected Routes */}
        <Route element={<ProtectedRoute />}>
          <Route path="/userMenu" element={<UserMenu />} />
          <Route path="/userInfo" element={<UserInfo />} />
          <Route path="/datausage" element={<Datausage />} />
          <Route path="/tickets" element={<Tickets />} />
          <Route path="/chatbot" element={<Chatbot />} />
          <Route path="/plans" element={<Plans />} />
          


        </Route>

        {/* Redirect all other paths to /login */}
        <Route path="*" element={<Navigate to="/login" replace />} />
      </Routes>
    </Router>
  );
}

export default App;