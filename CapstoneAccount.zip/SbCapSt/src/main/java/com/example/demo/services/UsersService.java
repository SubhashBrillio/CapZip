package com.example.demo.services;

import java.util.List;
import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.model.Users;
import com.example.demo.repo.UsersRepository;

@Service
@Transactional
public class UsersService implements UserDetailsService{

    @Autowired
    private UsersRepository usersRepository;
    
    @Autowired
    private PasswordEncoder passwordEncoder;
    
    

    // Retrieve all users
    public List<Users> getAllUsers() {
        return usersRepository.findAll();
    }

    // Search for a user by ID
    public Users getUserById(int userId) {
        return usersRepository.findById(userId).orElse(null); // Returns null if user not found
    }

    public String addUser(Users user) {
        user.setPasswordHash(passwordEncoder.encode(user.getPasswordHash())); // Encrypt password before saving
        user.setSecurityAnswer(passwordEncoder.encode(user.getSecurityAnswer()));
        user.setAccountStatus("Active");
        usersRepository.save(user);
        return "User registered successfully!";
    }

    
    // Update an existing user
    public String updateUser(String mobileNumber, Users updatedUser) {
		 usersRepository.save(updatedUser);
	        return "User updated successfully!";
		
	}

    // Delete a user by ID
    public String deleteUser(int userId) {
        usersRepository.deleteById(userId);
        return "User deleted successfully!";
    }
    
    public Users getUserByMobileNumber(String mobileNumber) {
        return usersRepository.findByMobileNumber(mobileNumber);
    }

    public ResponseEntity<Users> getUserInfo(String input) {
        Users user = null;
        if (isValidEmail(input)) {
            user = usersRepository.findByEmail(input);
        }
        else if (isValidMobileNumber(input)) {
            user = usersRepository.findByMobileNumber(input);
        }
        
        if (user != null) {
            return new ResponseEntity<>(user, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    // Utility method to check if input is a valid email
    private boolean isValidEmail(String email) {
        String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";
        return email.matches(emailRegex);
    }

    // Utility method to check if input is a valid mobile number
    private boolean isValidMobileNumber(String mobileNumber) {
        String mobileRegex = "^\\d{10}$"; // Assumes mobile number is 10 digits
        return mobileNumber.matches(mobileRegex);
    }
	
	
	
	public ResponseEntity<String> loginByEmail(String email, String password) {
        try {
        	Users user = usersRepository.findByEmail(email);
            long count = usersRepository.countByEmailAndPasswordHash(email, password); // Retrieve user by email
            String res="";
            res+=count;
            // Check password (assuming password is hashed)
            if (user != null && user.getPasswordHash().equals(password)) {
                return new ResponseEntity<>(res, HttpStatus.OK); // Successful login
            } else {
                return new ResponseEntity<>(res, HttpStatus.UNAUTHORIZED); // Invalid credentials
            }
        } catch (NoSuchElementException e) {
            return new ResponseEntity<>("User not found", HttpStatus.NOT_FOUND); // User not found
        }
    }
	
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        Users user = usersRepository.findByEmailOrMobileNumber(username, username)
                .orElseThrow(() -> new UsernameNotFoundException("User not found with email or mobile number: " + username));

        return new CustomUserDetails(user);
    }

    // Method to handle login with mobile number
    public ResponseEntity<String> loginByMobile(String mobileNumber, String password) {
        try {
            Users user = usersRepository.findByMobileNumber(mobileNumber);
            long count = usersRepository.countByMobileNumberAndPasswordHash(mobileNumber, password); // Retrieve user by email
            String res="";// Retrieve user by mobile number
            res+=count;
            // Check password (assuming password is hashed)
            if (user != null && user.getPasswordHash().equals(password)) {
                return new ResponseEntity<>(res, HttpStatus.OK); // Successful login
            } else {
                return new ResponseEntity<>(res, HttpStatus.UNAUTHORIZED); // Invalid credentials
            }
        } catch (NoSuchElementException e) {
            return new ResponseEntity<>("User not found", HttpStatus.NOT_FOUND); // User not found
        }
    }
    
    
	public Users getUserByEmail(String email) {
       return usersRepository.findByEmail(email);
   }
	
	
	
    
    /*
     * public String loginbyEmail(String email,String passwordHash) {
		long count=	usersRepository.countByEmailAndPasswordHash(email, passwordHash);
		String res ="";
		res+=count;
		return res;
	}*/


	// Get the security question by mobile number
    public String getSecurityQuestionByMobileNumber(String mobileNumber) {
        Users user = usersRepository.findByMobileNumber(mobileNumber);
        if (user != null) {
            return user.getSecurityQuestion();
        }
        throw new IllegalArgumentException("No user found for this mobile number.");
    }
 
    // Verify the security answer
    public boolean verifySecurityAnswer(String mobileNumber, String securityAnswer) {
        Users user = usersRepository.findByMobileNumber(mobileNumber);
        if (user != null) {
            return user.getSecurityAnswer().equalsIgnoreCase(securityAnswer);
        }
        throw new IllegalArgumentException("No user found for this mobile number.");
    }
 
    // Reset the password
    public String resetPassword(String mobileNumber, String newPassword) {
        Users user = usersRepository.findByMobileNumber(mobileNumber);
        if (user != null) {
            user.setPasswordHash(passwordEncoder.encode(newPassword));
            usersRepository.save(user);
            return "Password reset successfully!";
        }
        throw new IllegalArgumentException("Failed to reset the password. User not found.");
    }
	
}

