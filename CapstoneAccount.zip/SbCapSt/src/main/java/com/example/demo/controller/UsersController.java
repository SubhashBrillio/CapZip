package com.example.demo.controller;


import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.bind.annotation.*;

import com.example.demo.config.JwtService;
import com.example.demo.model.AuthRequest;
import com.example.demo.model.Users;
import com.example.demo.services.UsersService;


@RestController
@RequestMapping(value = "/accounts")
@CrossOrigin(origins = "http://localhost:3000")
public class UsersController {

    @Autowired
    private UsersService usersService;
    
    @Autowired
    private JwtService jwtService;

    @Autowired
    private AuthenticationManager authenticationManager;


    // Endpoint to fetch all users
    @GetMapping(value = "/getAllAccounts")
    public List<Users> getAllUsers() {
        return usersService.getAllUsers();
    }

    // Endpoint to fetch a user by ID
    @GetMapping(value = "/getAccount/{userId}")
    public ResponseEntity<Users> getUserById(@PathVariable int userId) {
        try {
            Users user = usersService.getUserById(userId);
            return new ResponseEntity<>(user, HttpStatus.OK);
        } catch (NoSuchElementException e) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @GetMapping("/getAccountByMobileNumber/{mobileNumber}")
    public ResponseEntity<Users> getUserByMobileNumber(@PathVariable String mobileNumber) {
        Users user = usersService.getUserByMobileNumber(mobileNumber);
        if (user != null) {
            return ResponseEntity.ok(user);
        } else {
            return ResponseEntity.notFound().build();
        }
    }
    
    @GetMapping(value = "/getAccountInfo/{input}")
    public ResponseEntity<Users> getUserInfo(@PathVariable String input) {
        return usersService.getUserInfo(input);
    }
    
   

    @GetMapping(value = "/accountLogin/{input}/{password}")
    public ResponseEntity<String> loginUser(@PathVariable String input, @PathVariable String password) {
    	try {
           
            // Check if the input is a valid email or mobile number
            if (isValidEmail(input)) {
                // If it's an email, call getUserByEmail//user = usersService.getUserByEmail(input);
//                
                System.out.println("Entered email");

                // Now call the login method with the email and password
                return usersService.loginByEmail(input, password);
                
            } else if (isValidMobileNumber(input)) {
                // If it's a mobile number, call getUserByMobileNumber
//                user = usersService.getUserByMobileNumber(input);
                System.out.println("Entered mobile");

                // Now call the login method with the mobile number and password
                return usersService.loginByMobile(input, password);

            } else {
                // Invalid input (not email or mobile number)
                return new ResponseEntity<>("-1", HttpStatus.BAD_REQUEST);
            }

        } catch (NoSuchElementException e) {
            return new ResponseEntity<>("User not found", HttpStatus.NOT_FOUND);
        }
    }

    // Method to validate if the input is a valid email
    private boolean isValidEmail(String email) {
        String emailRegex = "^[A-Za-z0-9+_.-]+@(.+)$";
        Pattern pattern = Pattern.compile(emailRegex);
        Matcher matcher = pattern.matcher(email);
        return matcher.matches();
    }

    // Method to validate if the input is a valid mobile number (assuming 10-digit number for this example)
    private boolean isValidMobileNumber(String mobileNumber) {
        String mobileNumberRegex = "^[0-9]{10}$"; // Change the regex if needed for different formats
        Pattern pattern = Pattern.compile(mobileNumberRegex);
        Matcher matcher = pattern.matcher(mobileNumber);
        return matcher.matches();
    }


    // Endpoint to add a new user
    @PostMapping(value = "/addAccount")
    public ResponseEntity<String> addNewUser(@RequestBody Users user) {
        try {
            String result = usersService.addUser(user);
            return ResponseEntity.ok(result);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error adding user: " + e.getMessage());
        }
    }
    
    @PostMapping("/generateToken")
    public ResponseEntity<String> authenticateAndGetToken(@RequestBody AuthRequest authRequest) {
        try {
            Authentication authentication = authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(authRequest.getUsername(), authRequest.getPassword()));
            if (authentication.isAuthenticated()) {
                String token = jwtService.generateToken(authRequest.getUsername());
                return ResponseEntity.ok(token);
            } else {
                throw new UsernameNotFoundException("Invalid user request!");
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Authentication failed: " + e.getMessage());
        }
    }

    // Endpoint to update an existing user
    @PutMapping("/updateAccount/{userId}")
    public ResponseEntity<String> updateUser(@PathVariable String mobileNumber, @RequestBody Users updatedUser) {
        try {
            String result = usersService.updateUser(mobileNumber, updatedUser);
            return ResponseEntity.ok(result);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error updating user: " + e.getMessage());
        }
    }

    // Endpoint to delete a user by ID
    @DeleteMapping(value = "/deleteAccount/{userId}")
    public ResponseEntity<Void> deleteUser(@PathVariable int userId) {
        try {
            usersService.getUserById(userId); // Check if user exists
            usersService.deleteUser(userId);
            return new ResponseEntity<>(HttpStatus.OK);
        } catch (NoSuchElementException e) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }
    
 // Admin-only profile access
    @GetMapping("/userProfile")
//    @PreAuthorize("hasAuthority('Admin')")
    public ResponseEntity<String> userProfile() {
        return ResponseEntity.ok("Welcome to User Profile");
    }
    
    @GetMapping("/getAccountByEmail/{email}")
    public ResponseEntity<Users> getUserByEmail(@PathVariable String email) {
        Users user = usersService.getUserByEmail(email);
        if (user != null) {
            return ResponseEntity.ok(user);
        } else {
            return ResponseEntity.notFound().build();
        }
    }
    
 // Fetch security question by mobile number
    @GetMapping("/securityQuestion/{mobileNumber}")
    public ResponseEntity<String> getSecurityQuestion(@PathVariable String mobileNumber) {
        try {
            String securityQuestion = usersService.getSecurityQuestionByMobileNumber(mobileNumber);
            return new ResponseEntity<>(securityQuestion, HttpStatus.OK);
        } catch (IllegalArgumentException e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
        }
    }
 
    // Verify the security answer and reset password
    @PostMapping("/resetPassword")
    public ResponseEntity<String> resetPassword(@RequestBody Map<String, String> payload) {
        String mobileNumber = payload.get("mobileNumber");
        String securityAnswer = payload.get("securityAnswer");
        String newPassword = payload.get("newPassword");
 
        if (mobileNumber == null || securityAnswer == null || newPassword == null) {
            return new ResponseEntity<>("Missing required fields.", HttpStatus.BAD_REQUEST);
        }
 
        if (!usersService.verifySecurityAnswer(mobileNumber, securityAnswer)) {
            return new ResponseEntity<>("Security answer is incorrect.", HttpStatus.UNAUTHORIZED);
        }
 
        try {
            usersService.resetPassword(mobileNumber, newPassword);
            return new ResponseEntity<>("Password reset successfully.", HttpStatus.OK);
        } catch (IllegalArgumentException e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
        }
    }

}
