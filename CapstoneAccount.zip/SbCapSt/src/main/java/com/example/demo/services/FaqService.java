package com.example.demo.services;
 
import java.util.List;
import java.util.Optional;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
 

import com.example.demo.model.SupportTickets;

import com.example.demo.repo.SupportTicketsRepository;
 
 
@Service
public class FaqService {
	
    @Autowired
    private SupportTicketsRepository supportTicketsRepository;
    
  
 
//    public String getTicketStatus(int userId) {
//        List<SupportTickets> tickets = supportTicketsRepository.findByUserId(userId);
//        if (tickets.isEmpty()) {
//            return "No tickets raised by you";
//        }
//        
//        StringBuilder message = new StringBuilder("Your tickets: \n");
//        for (SupportTickets ticket : tickets) {
//            message.append("Ticket ID: ").append(ticket.getTicketId()).append("\n")
//                         .append(", Status: ").append(ticket.getStatus()).append("\n")
//                         .append(", Issue : ").append(ticket.getIssue()).append("\n")
////       //                  .append(", Description : ").append(ticket.getTicketDescription()).append("\n")
//                         .append("\n");
//        }
//        return message.toString();
//    }
    
    public String getTicketStatus(int userId) {
        try {
            List<SupportTickets> tickets = supportTicketsRepository.findByUserId(userId);
            if (tickets.isEmpty()) {
                return "No tickets raised by you.";
            }
            
            StringBuilder message = new StringBuilder("Your tickets:\n");
            for (SupportTickets ticket : tickets) {
                message.append("Ticket ID: ").append(ticket.getTicketId()).append("\n")
                       .append("Status: ").append(ticket.getStatus()).append("\n")
                       .append("Issue: ").append(ticket.getIssue()).append("\n\n");
            }
            return message.toString();
        } catch (Exception e) {
            return "An error occurred while fetching your ticket status. Please try again later.";
        }
    }

 
    
}
 