package com.example.demo.controller;

import java.util.List;
import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.SupportTickets;
import com.example.demo.services.SupportTicketsService;


@CrossOrigin(origins = "http://localhost:3000") // Allow frontend to access backend
@RestController
@RequestMapping("/supportTickets")
public class SupportTicketsController {
	
	@Autowired
	private SupportTicketsService supportTicketsServices;
	
	@GetMapping(value = "/showSupportTickets")
	public List<SupportTickets> showSupportTickets(){
		return supportTicketsServices.showSupportTickets();
	}
	
	@GetMapping(value = "/searchSupportTickets/{id}")
	public ResponseEntity<SupportTickets> get(@PathVariable int id){
		try {
			SupportTickets supportTickets = supportTicketsServices.searchById(id);
			return new ResponseEntity<SupportTickets>(supportTickets,HttpStatus.OK);
		} catch(NoSuchElementException e){
			return new ResponseEntity<SupportTickets>(HttpStatus.NOT_FOUND);
		}
	}
	
	@PostMapping(value = "/addSupportTickets")
	public void addSupportTickets(@RequestBody SupportTickets supportTickets) {
		supportTicketsServices.addSupportTickets(supportTickets);
	}
	
	
	
	@GetMapping(value = "/searchAccount/{userId}")
	public ResponseEntity<List<SupportTickets>> getByUser(@PathVariable int userId){
		try {
			List<SupportTickets> supportTicketsList = supportTicketsServices.searchByUserId(userId);
			return new ResponseEntity<List<SupportTickets>>(supportTicketsList,HttpStatus.OK);
		} catch (NoSuchElementException e) {
			return new ResponseEntity<List<SupportTickets>>(HttpStatus.NOT_FOUND);
		}
	}

	@GetMapping(value = "/searchEmploy/{employId}")
	public ResponseEntity<List<SupportTickets>> getByEmploy(@PathVariable int employId){
		try {
			List<SupportTickets> supportTicketsList = supportTicketsServices.searchByEmployId(employId);
			return new ResponseEntity<List<SupportTickets>>(supportTicketsList,HttpStatus.OK);
		} catch (NoSuchElementException e) {
			return new ResponseEntity<List<SupportTickets>>(HttpStatus.NOT_FOUND);
		}
	}
	
	@PutMapping(value = "/updateSupportTicket")
	public ResponseEntity<Void> updateSupportTickets(@RequestBody SupportTickets supportTickets){
		try {
			supportTicketsServices.searchById(supportTickets.getTicketId());
			supportTicketsServices.updateSupportTickets(supportTickets);
			return new ResponseEntity<>(HttpStatus.OK);
		}catch (NoSuchElementException e) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
		
	}
	
	
	

}
