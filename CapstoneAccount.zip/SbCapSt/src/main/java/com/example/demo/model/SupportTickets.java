package com.example.demo.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@Entity
@Table(name = "Support_tickets") 
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class SupportTickets {

	@Id
	@Column(name="ticket_id")
	private int ticketId;
	@Column(name="user_id")
    private int userId;
	@Column(name="employ_id")
    private int employId;
	@Column(name="issue")
    private String issue;
	@Column(name="status")
    private String status;
	@Column(name="created_at")
    private String createdAt;
	@Column(name="updated_at")
    private String updatedAt;

//    // Set createdAt when a new ticket is created
//    @PrePersist
//    protected void onCreate() {
//        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
//        createdAt = LocalDateTime.now().format(formatter);
//        updatedAt = createdAt; // Set initial updatedAt value same as createdAt
//    }
//
//    // Auto-update updatedAt before any update
//    @PreUpdate
//    protected void onUpdate() {
//        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
//        updatedAt = LocalDateTime.now().format(formatter);
//    }
}
