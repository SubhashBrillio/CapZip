package com.example.demo.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.example.demo.model.Employ;
import com.example.demo.repo.EmployRepository;

@Service
public class EmployService implements UserDetailsService{
	
	@Autowired
	private PasswordEncoder encoder;
	
	@Autowired
	private EmployRepository employRepository;
	
	public List<Employ> showEmploy(){
		return employRepository.findAll();
	}
	
	public Employ searchEmploy(int empId) {
		return employRepository.findById(empId).orElse(null);
	}
	public Employ searchByfirstname(String firstName) {
		return employRepository.findByFirstName(firstName);
	}
 
	public String addEmploy(Employ employ) {
		employ.setPasswordHash(encoder.encode(employ.getPasswordHash()));
		employRepository.save(employ);
		return "Employ Added Successfully";
	}
	
	public void updateEmploy(Employ employ) {
		employRepository.save(employ);
	}
	
	public void deleteEmploy(int empId) {
		employRepository.deleteById(empId);
	}
	
	public String login(String employUserName, String passwordHash) {
		long count=	employRepository.countByEmployUserNameAndPasswordHash(employUserName, passwordHash);
		String res ="";
		res+=count;
		return res;
	}

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		Optional<Employ> userDetail = employRepository.findByEmployUserName(username);
		return userDetail.map(UserDataDetails :: new)
				.orElseThrow( () -> new UsernameNotFoundException("Employ Not Found" +username));
	}
	
}

	
