package com.example.demo.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "Support_tickets") 
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class SupportTickets {
	
	@Id
	@Column(name="ticket_id")
	private int ticketId;
	@Column(name="user_id")
    private int userId;
	@Column(name="employ_id")
    private int employId;
	@Column(name="issue")
    private String issue;
	@Column(name="status")
    private String status;
	@Column(name="created_at")
    private String createdAt;
	@Column(name="updated_at")
    private String updatedAt;


}
