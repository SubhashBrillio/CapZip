package com.example.demo.repo;


import com.example.demo.model.datausage;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface DataUsageRepository extends JpaRepository<datausage, Integer> {
    List<datausage> findByUserId(int userId);
}