package com.example.demo.repo;

import java.util.Optional;

//import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


import com.example.demo.model.Users;

@Repository
public interface UsersRepository extends JpaRepository<Users, Integer> {
	Users findByMobileNumber(String mobileNumber);
	long countByMobileNumberAndPasswordHash(String mobileNumber,String passwordHash);
	long countByEmailAndPasswordHash(String email,String passwordHash);
	Optional<Users> findByEmailOrMobileNumber(String email, String mobileNumber);
	Users findByEmail(String email);
//	Optional<Users> findByEmail(String email);
}