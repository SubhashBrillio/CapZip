package com.example.demo.repo;

import com.example.demo.model.Transactions;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface TransactionsRepository extends JpaRepository<Transactions, Integer> {
    List<Transactions> findByUserId(int userId);
}