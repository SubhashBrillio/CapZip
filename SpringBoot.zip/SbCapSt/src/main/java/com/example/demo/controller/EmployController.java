package com.example.demo.controller;

import java.util.List;

import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.config.JwtService;
import com.example.demo.model.AuthRequest;
import com.example.demo.model.Employ;
import com.example.demo.services.EmployService;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

@RestController
@RequestMapping(value="/employ")
public class EmployController {

		@Autowired
		private EmployService employService;
		
		@Autowired
	    private JwtService jwtService;
	 
	    @Autowired
	    private AuthenticationManager authenticationManager;
	    
	    
		@GetMapping(value="/showEmploy")
		public List<Employ> showEmploy(){
			return employService.showEmploy();
		}
		
		@GetMapping(value="/searchEmploy/{id}")
		public ResponseEntity<Employ> searchEmploy(@PathVariable int id){
			try {
					Employ employ = employService.searchEmploy(id);
					return new ResponseEntity<Employ>(employ,HttpStatus.OK);
			}catch(NoSuchElementException e) {
				return new ResponseEntity<Employ>(HttpStatus.NOT_FOUND);
			}
		}
		
		@PutMapping(value="/updateEmploy")
		public ResponseEntity<Employ> updateEmploy(@RequestBody Employ employ){
			try {
				employService.searchEmploy(employ.getEmployId());
				employService.updateEmploy(employ);
				return new ResponseEntity<Employ>(HttpStatus.OK);
			}catch(NoSuchElementException e) {
				return new ResponseEntity<Employ>(HttpStatus.NOT_FOUND);
			}
			
		}
		
		@DeleteMapping(value="/deleteEmploy/{id}")
		public ResponseEntity<Employ> deleteEmploy(@PathVariable int id, @RequestBody Employ employ){
			try {
				employService.searchEmploy(employ.getEmployId());
				employService.deleteEmploy(id);
				return new ResponseEntity<Employ>(HttpStatus.OK);
			}catch(NoSuchElementException e) {
				return new ResponseEntity<Employ>(HttpStatus.NOT_FOUND);
			}
		
		
		}
		
		@PostMapping(value="/addEmploy")
		public ResponseEntity<Void> addEmploy(@RequestBody Employ employ) {
			try {
				employService.addEmploy(employ);
				return new ResponseEntity<>(HttpStatus.CREATED);
			} catch (Exception e) {
	            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
	            
			}
			
		}
		
		@GetMapping(value="/searchByFirstName/{firstname}")
		 public ResponseEntity<Employ> getUserByMobileNumber(@PathVariable String firstname) {
	        try {
	            Employ employ = employService.searchByfirstname(firstname); // Assuming such a service method exists
	            return new ResponseEntity<Employ>(employ,HttpStatus.OK);
	        } catch (NoSuchElementException e) {
	            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	        }
		}
		
		@GetMapping(value="/employLogin/{user}/{pwd}")
		public String login(@PathVariable String user,@PathVariable String pwd) {
			return employService.login(user, pwd);
		}
		
		
		@GetMapping("/employdashboard/employProfile")
	    @PreAuthorize("hasAuthority('Admin') or hasAuthority('Technical') or hasAuthority('Staff')")
	    public String adminProfile() {
	        return "Welcome to Admin Profile";
	    }
		
		 @PostMapping("/generateToken")
		    public String authenticateAndGetToken(@RequestBody AuthRequest authRequest) {
		        Authentication authentication = authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(authRequest.getUsername(), authRequest.getPassword()));
		        if (authentication.isAuthenticated()) {
		            return jwtService.generateToken(authRequest.getUsername());
		        } else {
		            throw new UsernameNotFoundException("invalid user request !");
		        }
		    }
		
}
