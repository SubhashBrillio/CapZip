package com.example.demo.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "Transactions") 
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Transactions {
	
	@Id
	@Column(name="transaction_id")
	private int transactionId;
	@Column(name="user_id")
    private int userId;
	@Column(name="plan_id")
    private int planId;
	@Column(name="transaction_status")
    private String transactionStatus;
	@Column(name="payment_mode")
    private String paymentMode;
	@Column(name="transaction_timestamp")
    private String transactionTimestamp;

}
